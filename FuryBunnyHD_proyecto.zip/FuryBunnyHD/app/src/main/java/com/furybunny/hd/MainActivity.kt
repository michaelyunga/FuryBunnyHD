package com.furybunny.hd

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.FileInputStream
import java.nio.ByteBuffer

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var src: Uri? = null
    private var srcName = "video.mp4"
    private var pre = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }
    private fun fail(m: String) = js("fbFail(" + JSONObject.quote(m) + ")")

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data
        if (rc != 1 || res != RESULT_OK || u == null) return
        src = u
        var size = 0L
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) srcName = c.getString(i)
                val j = c.getColumnIndex(OpenableColumns.SIZE)
                if (j >= 0) size = c.getLong(j)
            }
        }
        js("onPicked(" + JSONObject.quote(srcName) + "," + size + ")")
    }

    private fun readMoov() {
        val u = src ?: throw Exception("Elige un video primero")
        contentResolver.openFileDescriptor(u, "r")!!.use { pfd ->
            val ch = FileInputStream(pfd.fileDescriptor).channel
            val size = ch.size()
            var p = 0L
            var lastP = 0L
            var lastT = ""
            val bb = ByteBuffer.allocate(16)
            while (p < size) {
                bb.clear(); ch.read(bb, p)
                var s = bb.getInt(0).toLong() and 0xFFFFFFFFL
                val t = String(bb.array(), 4, 4, Charsets.ISO_8859_1)
                if (s == 1L) s = bb.getLong(8) else if (s == 0L) s = size - p
                if (s < 8) throw Exception("Archivo MP4 dañado")
                lastP = p; lastT = t; p += s
            }
            if (lastT != "moov") throw Exception("Este video tiene el índice al inicio; todavía no es compatible.")
            val mb = ByteBuffer.allocate((size - lastP).toInt())
            var q = lastP
            while (mb.hasRemaining()) { val n = ch.read(mb, q); if (n < 0) break; q += n }
            pre = lastP
            js("fbRun('" + Base64.encodeToString(mb.array(), Base64.NO_WRAP) + "'," + lastP + ")")
        }
    }

    private fun writeOut(a: String, b: String, c: String) {
        val u = src ?: return
        val name = srcName.substringBeforeLast('.') + "_FuryBunny.mp4"
        val cv = ContentValues()
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, name)
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FuryBunnyHD")
        cv.put(MediaStore.Video.Media.IS_PENDING, 1)
        val out = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
            ?: throw Exception("No se pudo crear el archivo")
        try {
            contentResolver.openOutputStream(out)!!.use { os ->
                contentResolver.openInputStream(u)!!.use { ins ->
                    val buf = ByteArray(1 shl 20)
                    var left = pre
                    var done = 0L
                    var lastPct = -1
                    while (left > 0) {
                        val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) throw Exception("Lectura incompleta")
                        os.write(buf, 0, n); left -= n; done += n
                        val pct = (done * 100 / pre).toInt()
                        if (pct != lastPct) { lastPct = pct; js("fbProgress($pct)") }
                    }
                }
                for (s in listOf(a, b, c)) os.write(Base64.decode(s, Base64.DEFAULT))
            }
            val done = ContentValues()
            done.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(out, done, null, null)
            js("fbDone(" + JSONObject.quote(name) + ")")
        } catch (e: Exception) {
            contentResolver.delete(out, null, null)
            fail("No se pudo guardar: " + e.message)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun pick() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.type = "video/*"
                i.addCategory(Intent.CATEGORY_OPENABLE)
                @Suppress("DEPRECATION") startActivityForResult(i, 1)
            }
        }
        @JavascriptInterface fun process() {
            Thread { try { readMoov() } catch (e: Exception) { fail("No se pudo leer el video: " + e.message) } }.start()
        }
        @JavascriptInterface fun deliver(a: String, b: String, c: String) {
            Thread { try { writeOut(a, b, c) } catch (e: Exception) { fail("No se pudo guardar: " + e.message) } }.start()
        }
        @JavascriptInterface fun err(m: String) { fail(m) }
    }
}
